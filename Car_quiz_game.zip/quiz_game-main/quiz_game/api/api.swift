import Foundation


let ACCESS_EKY = "$2b$10$u74h4vIc.dITETD7Fvc5mOpEVYCn8SVn2WuvFSmgJNhOJLWpd8P5a"
let BASE_URL = "https://api.jsonbin.io/v3/b/628b8f80449a1f3821eb01e8"
