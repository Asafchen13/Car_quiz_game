//
//  QuestionsViewModel.swift
//  quiz_game
//
//  Created by Vladi Khagay on 13/05/2022.
//

import Foundation


struct QuestionsViewModel {
    var questions: String
}
