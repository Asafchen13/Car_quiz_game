//
//  ViewController.swift
//  quiz_game
//
//  Created by Asaf Chen on 30/05/2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

