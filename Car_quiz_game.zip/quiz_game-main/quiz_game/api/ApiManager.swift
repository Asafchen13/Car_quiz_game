import Foundation

let BASE_URL = "https://api.jsonbin.io/b/6293f49b402a5b380213b1a7"


class ApiManager {
    
    
    func performRequest(comp: @escaping([Question])->()){
        if let url: URL = URL(string: BASE_URL) {
            let session = URLSession(configuration: .default)
            
            let task = session.dataTask(with: url) { (data, repsonse, error) in
                
                if (error != nil){
                    print("error: \(String(describing: error))")
                    return
                }
                
                do {
                    let result  = try JSONDecoder().decode([Question].self, from: data!)
                    comp(result)
                } catch {
                    
                    print("error: \(Error.self)")
                }
                
                
            }
            
            task.resume()
        }
        
    }
    
    
}
