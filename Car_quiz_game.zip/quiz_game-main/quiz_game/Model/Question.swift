//
//  Question.swift
//  quiz_game
//
//  Created by Asaf Chen on 15/05/2022.
//

import Foundation


struct Question: Codable {
    var correct_answer: String?
    var incorrect_answers: [String]
    var imageUrl:String?
}
